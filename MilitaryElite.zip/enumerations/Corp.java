package enumerations;

public enum Corp {
    Airforces,
    Marines,
}
