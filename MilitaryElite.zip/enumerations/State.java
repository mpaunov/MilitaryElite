package enumerations;

public enum State {
    inProgress,
    Finished,
}
