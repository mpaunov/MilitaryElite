package interfaces;

public interface LeutenantGeneral {
    public void addPrivate(Private priv);
}
