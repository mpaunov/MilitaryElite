package interfaces;

public interface Private extends Soldier {

}
