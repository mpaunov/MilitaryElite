package interfaces;

public interface Mission {
    @Override
    public String toString();
}
