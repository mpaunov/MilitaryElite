package interfaces;

public interface SpecialisedSoldier extends Soldier {
}