package interfaces;

public interface Spy {
}
